
(function(){
 'use strict';
 let pending=0,helpIndex=0;const helpPages=[];
 function fitBox(element,parent){
  if(!element||!parent||!element.getClientRects().length)return;
  element.style.transform='none';
  const css=getComputedStyle(parent);
  const width=Math.max(1,parent.clientWidth-parseFloat(css.paddingLeft||0)-parseFloat(css.paddingRight||0)-4);
  const height=Math.max(1,parent.clientHeight-parseFloat(css.paddingTop||0)-parseFloat(css.paddingBottom||0)-4);
  const actualWidth=Math.max(element.offsetWidth,element.scrollWidth);
  const actualHeight=Math.max(element.offsetHeight,element.scrollHeight);
  const scale=Math.min(1,width/Math.max(1,actualWidth),height/Math.max(1,actualHeight));
  element.style.transform='scale('+Math.max(.0001,scale)+')';
 }
 function fitViewport(){
  pending=0;
  const v=window.visualViewport;
  const height=Math.max(1,Math.floor(v?v.height:window.innerHeight));
  document.documentElement.style.setProperty('--app-vh',height+'px');
  document.body.style.setProperty('height',height+'px','important');
  const chrome=document.getElementById('chromeContent'),frame=document.getElementById('chromeViewport');
  if(chrome&&frame&&document.body.dataset.screen==='game'){
   chrome.style.width=frame.clientWidth+'px';chrome.style.transform='none';
   const natural=Math.max(chrome.scrollHeight,chrome.offsetHeight);
   const landscape=window.innerWidth>height&&height<520;
   const share=landscape?(instructionsPanelOpen ? 0.48 : 0.34):(instructionsPanelOpen ? 0.48 : 0.38);
   const scale=Math.min(1,(height*share)/Math.max(1,natural));
   chrome.style.transform='scale('+scale+')';
   // Expand the unscaled width so small screens use the full available row.
   if(scale<1){chrome.style.width=(frame.clientWidth/scale)+'px';}
   const fittedHeight=Math.max(chrome.offsetHeight,chrome.scrollHeight)*scale;
   frame.style.height=Math.ceil(fittedHeight)+'px';
  }
  fitBox(document.querySelector('.menu-shell'),document.getElementById('startScreen'));
  fitBox(document.getElementById('quizCard'),document.getElementById('quizViewContainer'));
  for(const [outer,inner] of [['lessonResult','.result-card'],['certificateDialog','.certificate-card'],['postDialog','.post-card'],['feedbackModal',':scope > div'],['celebrationOverlay','.celebration-card'],['deviceHelpDialog','.device-help-card']]){
   const parent=document.getElementById(outer);if(parent)fitBox(parent.querySelector(inner),parent);
  }
  if(typeof levels!=='undefined'&&levels[currentLevelIndex].type!=='quiz'&&document.body.dataset.screen==='game')layoutBoard();
 }
 function schedule(){if(!pending)pending=requestAnimationFrame(fitViewport);}
 function showHelpPage(){
  const body=document.getElementById('deviceHelpBody');body.textContent=helpPages[helpIndex]||'';
  document.getElementById('deviceHelpCount').textContent=(helpIndex+1)+' / '+helpPages.length;
  document.getElementById('deviceHelpPrevious').disabled=helpIndex===0;
  document.getElementById('deviceHelpNext').disabled=helpIndex===helpPages.length-1;
  schedule();
 }
 function openModelHelp(event){
  if(event)event.preventDefault();helpPages.length=0;
  const description=document.getElementById('taskDesc').textContent;if(description)helpPages.push(description);
  for(const paragraph of document.querySelectorAll('#modelNotes p'))helpPages.push(paragraph.textContent);
  helpIndex=0;document.getElementById('deviceHelpDialog').hidden=false;showHelpPage();
  document.getElementById('deviceHelpClose').focus();
 }
 function ready(){
  const app=document.getElementById('appViewport');
  const frame=document.createElement('div');frame.id='chromeViewport';
  const chrome=document.createElement('div');chrome.id='chromeContent';frame.appendChild(chrome);
  document.body.insertBefore(frame,app);
  for(const id of ['phoneNavigation'])chrome.appendChild(document.getElementById(id));
  chrome.appendChild(document.querySelector('header'));
  for(const id of ['panelControls','liveBar','wireLegend','savedLevelBar','objectivePanel','wiringStatusPanel','boardTools'])chrome.appendChild(document.getElementById(id));
  document.getElementById('levelPanelToggle').textContent=levelsPanelOpen?'Hide levels':'Show levels';
  const overlay=document.createElement('div');overlay.id='deviceHelpDialog';overlay.hidden=true;overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-labelledby','deviceHelpTitle');
  overlay.innerHTML='<section class="device-help-card"><h2 id="deviceHelpTitle">Model and lesson notes</h2><p id="deviceHelpBody"></p><div class="device-help-actions"><button id="deviceHelpPrevious" type="button">Previous</button><span id="deviceHelpCount"></span><button id="deviceHelpNext" type="button">Next</button></div><div class="device-help-actions"><button id="deviceHelpClose" type="button">Back to circuit</button></div></section>';
  document.body.appendChild(overlay);
  document.getElementById('deviceHelpPrevious').onclick=()=>{if(helpIndex>0){helpIndex--;showHelpPage();}};
  document.getElementById('deviceHelpNext').onclick=()=>{if(helpIndex<helpPages.length-1){helpIndex++;showHelpPage();}};
  document.getElementById('deviceHelpClose').onclick=()=>{overlay.hidden=true;document.querySelector('#modelNotes summary').focus();};
  document.querySelector('#modelNotes summary').addEventListener('click',openModelHelp);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!overlay.hidden)overlay.hidden=true;});
  const observer=new MutationObserver(records=>{
   if(records.some(r=>!(r.target.nodeType===1?r.target:r.target.parentElement)?.closest('#boardSurface,#celebrationParticles')))schedule();
  });
  observer.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['hidden','class','open','data-screen','data-mode']});
  if(window.ResizeObserver){const resizer=new ResizeObserver(schedule);resizer.observe(document.body);resizer.observe(chrome);}
  window.addEventListener('resize',schedule,{passive:true});window.addEventListener('orientationchange',schedule,{passive:true});
  if(window.visualViewport){window.visualViewport.addEventListener('resize',schedule,{passive:true});window.visualViewport.addEventListener('scroll',schedule,{passive:true});}
  if(document.fonts&&document.fonts.ready)document.fonts.ready.then(schedule);
  schedule();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
})();

