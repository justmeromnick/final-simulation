
function syncVisibleLevelNavigation(){
 const title=document.getElementById('currentLessonTitle');
 if(!title)return;
 const level=levels[currentLevelIndex];
 if(title.textContent!==level.title)title.textContent=level.title;
 const status=document.getElementById('currentLessonState');
 const statusText=completedLevels.has(currentLevelIndex)?'Completed ✓':'In progress';
 if(status.textContent!==statusText)status.textContent=statusText;
 const chooser=document.getElementById('phoneLevelSelect');if(chooser)chooser.value=String(currentLevelIndex);
 document.querySelectorAll('#levelChoiceButtons button').forEach((button,index)=>{
  const selected=index===currentLevelIndex,done=completedLevels.has(index);
  if(selected){if(button.getAttribute('aria-current')!=='step')button.setAttribute('aria-current','step');}
  else if(button.hasAttribute('aria-current'))button.removeAttribute('aria-current');
  if(button.dataset.complete!==String(done))button.dataset.complete=String(done);
  const label=(index+1)+(done?' ✓':'');
  if(button.textContent!==label)button.textContent=label;
  const accessible=levels[index].title+(selected?' — selected':'')+(done?' — completed':'');
  if(button.getAttribute('aria-label')!==accessible)button.setAttribute('aria-label',accessible);
 });
}
document.addEventListener('DOMContentLoaded',()=>{
 const navigation=document.getElementById('phoneNavigation');
 const current=document.createElement('section');current.id='currentLessonBar';current.setAttribute('aria-label','Selected level');
 const title=document.createElement('strong');title.id='currentLessonTitle';title.setAttribute('aria-live','polite');
 const status=document.createElement('span');status.id='currentLessonState';current.append(title,status);
 navigation.parentNode.insertBefore(current,navigation);
 const buttons=document.createElement('div');buttons.id='levelChoiceButtons';buttons.setAttribute('role','group');buttons.setAttribute('aria-label','Choose level');
 levels.forEach((level,index)=>{const button=document.createElement('button');button.type='button';button.title=level.title;button.onclick=()=>loadLevel(index);buttons.appendChild(button);});
 navigation.appendChild(buttons);syncVisibleLevelNavigation();
});

