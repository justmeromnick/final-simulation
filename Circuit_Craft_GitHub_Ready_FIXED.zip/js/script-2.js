
// Keep the active colour visible without relying on hover or tiny borders.
const wirePalette = document.getElementById('wireColorPicker');
function togglePhoneTools() {
 const open=document.body.classList.toggle('phone-tools-open');
 document.getElementById('phoneToolsBtn').setAttribute('aria-expanded',String(open));
}
function syncWirePalette() {
 wirePalette.querySelectorAll('button').forEach(button => {
  button.setAttribute('aria-pressed', String(button.id === 'colorBtn_' + selectedWireColor));
 });
}
wirePalette.addEventListener('click', syncWirePalette);
syncWirePalette();
// Older Safari releases use the visible viewport as a fallback for dynamic vh.
if (!CSS.supports('height', '100dvh')) {
 const fitVisibleViewport = () => document.body.style.setProperty('height', window.innerHeight + 'px', 'important');
 window.addEventListener('resize', fitVisibleViewport, {passive:true});
 fitVisibleViewport();
}

